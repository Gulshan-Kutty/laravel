<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel CRUD</title>
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark">

        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="<?php echo e(route('products.index')); ?>">Products</a>
          </li>
        </ul>
      
      </nav>
    <div class="container">
       <div class="row justify-content-center">
          <div class="col-sm-8">
            <div class="card mt-3 p-3">
              <form method='POST' action="<?php echo e(route('products.store')); ?>" enctype='multipart/form-data'>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="">Name</label>
                  <input type="text" name='name' class='form-control' placeholder="Please Enter Name" value=<?php echo e($product->name ?? old('name')); ?>>
                  
                  <?php if($errors->has('name')): ?> 
                  <span class='text-danger'><?php echo e($errors->first('name')); ?></span> 
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="">Description</label>
                  <textarea class='form-control' name="description" id="" cols="30" rows="10"><?php echo e($product->description ?? old('description')); ?></textarea> 
                  <?php if($errors->has('description')): ?>
                  <span class='text-danger'><?php echo e($errors->first('description')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="">Image</label>
                  <input type="file" name='image' class='form-control' value=<?php echo e($product->image ?? old('image')); ?>>
                  <?php if($errors->has('image')): ?>
                  <span class='text-danger'><?php echo e($errors->first('image')); ?></span>
                  <?php endif; ?>
                </div>
                <input type="hidden" name="id" value="<?php echo e($product->id ?? ''); ?>">
                <button type='submit' value="<?php echo e($title); ?>" name="button" class='btn btn-dark'><?php echo e($title); ?></button>
                <a class="btn btn-danger" href="<?php echo e(route('products.index')); ?>">Cancle</a>
              </form>
            </div>
          </div>
       </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\crud_operations\resources\views/products/create.blade.php ENDPATH**/ ?>