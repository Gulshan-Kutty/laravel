<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(url('resources/css/bootstrap.min.css')); ?>">
    <title>Export</title>
</head>
<body>
    <table border="1px">
        <thead>
            <tr>
               <th colspan="9" align="center" style="background: #ffffb3"><b>Product Details</b></th>
            </tr>
        <tr>
            <th style="background: #ccffff"><b>Name</b></th>
            <th style="background: #ccffff"><b>Description</b></th>
            <th style="background: #ccffff"><b>From_date</b></th>
            <th style="background: #ccffff"><b>To_date</b></th>
            <th style="background: #ccffff"><b>Countries</b></th>
            <th style="background: #ccffff"><b>Image</b></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->description); ?></td>
                <td><?php echo e($product->from_date); ?></td>
                <td><?php echo e($product->to_date); ?></td>
                <td><?php echo e($product->countries->pluck('country.country_name')->implode(', ')); ?></td>
                <td><?php echo e(url('public/users/'.$product->image)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\my_crud_1_to_many_yajra\resources\views/products/pdf.blade.php ENDPATH**/ ?>