<?php

namespace App\Imports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\ToModel;

class UserImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Product([
           'id'=>$row[0],
           'name'=>$row[1],
           'description'=>$row[2],
           'from_date'=>$row[3],
           'to_date'=>$row[4],
           'image'=>$row[5],
           'created_at'=>$row[6],
           'updated_at'=>$row[7],

        ]);
    }
}
