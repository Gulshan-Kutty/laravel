<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>homepage</title>
    <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{url('public/css/bootstrap-toaster.min.css')}}">
    
    <script src="{{url('public/js/jquery-3.7.1.min.js')}}"></script>
    {{-- Yajra Datatables related scripts and links --}}
    <link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>


    <style>
        .navbar {
            height: 80px; /* Change the height value as needed */
        }
    
    </style>
</head>
<body>
    @php
        // print_r($data1->toArray());exit;
    @endphp
    <nav class="navbar navbar-expand-sm bg-dark">
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="{{route('products.home')}}">Homepage</a>
          </li>
        </ul>
      </nav>
      <div class="container">
        <h3>Import data</h3>
        <form action="{{route('products.import')}}" method="POST" enctype="multipart/form-data">
          @csrf
        <input type="file" name="file">
        <button type="submit" class="btn btn-success">submit</button>
      </form>
      <br>
        <form class='mt-2' action="{{route('products.export')}}" method="POST" enctype="multipart/form-data">
          @csrf 
          <label for="from">From date</label>
          <input type="text" id="from" name="from" autocomplete="off">
          <label for="to">To date</label>
          <input type="text" id="to" name="to"autocomplete="off">
          <button type="submit" class="btn btn-success" >Export Excel</button>
          {{-- &nbsp;<a href="{{route('user.export_d')}}" class="btn btn-success float-right mt-2 mb-2" id="date">export d</a>&nbsp; --}}
        </form>
        <div class="row">
            <h2 class='mt-3 ml-3'>Products List</h2>
            <button type='submit' class='btn btn-primary m-3 ml-auto ' onclick="window.location='{{ route('products.create')}}'">Create Product</button>
            &nbsp;<a href="{{route('products.pdf',)}}" class="btn btn-success float-right mt-2 mb-2">Download pdf&darr;</a>&nbsp;

        </div>
        
        {{-- Yajra Datatable related code --}}
        <table class='table table-bordered datatable mt-4'>
            <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>From Date</th>
                    <th>To Date</th>
                    <th>Country</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        
    </div>
    </body>

    {{-- Yajra Datatables related code --}}
    <script type="text/javascript">
        $(function () {
            
          var table = $('.datatable').DataTable({
              processing: true,
              serverSide: true,
              ajax: "{{ route('products.ajax_product') }}",
              columns: [
                  {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                  {data: 'name', name: 'name'},
                  {data: 'description', name: 'description'},
                  {data: 'from_date', name: 'from_date', orderable: false, searchable: false},
                  {data: 'to_date', name: 'to_date', orderable: false, searchable: false},
                  {data: 'country', name: 'country'},
                  {data: 'image', name: 'image'},
                  {data: 'action', name: 'action'},
              ]
            //   name corresponds to the database table column name, and it's used by DataTables for server-side processing tasks like sorting and filtering.
          });
            
        });
      </script>

      <script>
        function exportTasks(_this) {
          let _url = $(_this).data('href');
          window.location.href = _url;
        }
      </script>

      {{-- datepicker --}}
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

      <script>
        $( function() {
        var dateFormat = "yy/mm/dd",
          from = $( "#from" )
            .datepicker({
              dateFormat:"yy-mm-dd",
              defaultDate: "+1w",
              changeMonth: true,
              numberOfMonths: 1
            })
            .on( "change", function() {
              to.datepicker( "option", "minDate", getDate( this ) );
            }),
          to = $( "#to" ).datepicker({
            dateFormat:"yy-mm-dd",
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1
          })
          .on( "change", function() {
            from.datepicker( "option", "maxDate", getDate( this ) );
          });
     
        function getDate( element ) {
          var date;
          try {
            date = $.datepicker.parseDate( dateFormat, element.value );
          } catch( error ) {
            date = null;
          }
     
          return date;
        }
      } );
      </script>
    </html>
