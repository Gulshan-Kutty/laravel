-- Adminer 4.8.1 MySQL 8.0.36 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `my_crud_1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `my_crud_1`;

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `state_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `cities` (`id`, `city_name`, `state_id`, `created_at`, `updated_at`) VALUES
(1,	'San Diego',	3,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(2,	'Los Angeles',	3,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(3,	'San Jose',	3,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(4,	'San Francisco',	3,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(5,	'Fresno',	3,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(6,	'Phoenix',	4,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(7,	'Tucson',	4,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(8,	'Mesa',	4,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(9,	'Chandler',	4,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(10,	'Houston',	5,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(11,	'San Antonio',	5,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(12,	'Dallas',	5,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(13,	'Austin',	5,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(14,	'Garland',	5,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(15,	'Calgary',	1,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(16,	'Strathcona County',	1,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(17,	'Canmore',	1,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(18,	'Medicine Hat',	1,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(19,	'Toronto',	2,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(20,	'Ottawa',	2,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(21,	'Mississauga',	2,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(22,	'Amaravati',	6,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(23,	'Anantapur',	6,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(24,	'Bhimavaram',	6,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(25,	'Chirala',	6,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(26,	'Lucknow',	7,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(27,	'Kanpur',	7,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(28,	'Varanasi',	7,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(29,	'Mumbai',	8,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(30,	'Pune',	8,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(31,	'Nagpur',	8,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33'),
(32,	'Nasik',	8,	'2024-06-10 11:28:33',	'2024-06-10 11:28:33');

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `countries` (`id`, `country_name`, `created_at`, `updated_at`) VALUES
(1,	'India',	'2024-06-10 11:07:04',	'2024-06-10 11:07:04'),
(2,	'United States',	'2024-06-10 11:07:04',	'2024-06-10 11:07:04'),
(3,	'Canada',	'2024-06-10 11:07:04',	'2024-06-10 11:07:04');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `hobbies`;
CREATE TABLE `hobbies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hobby_name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `hobbies` (`id`, `hobby_name`, `created_at`, `updated_at`) VALUES
(1,	'Reading',	'2024-06-06 12:40:09',	'2024-06-06 12:40:09'),
(2,	'Dancing',	'2024-06-06 12:40:46',	'2024-06-06 12:40:46'),
(3,	'Playing',	'2024-06-06 12:40:51',	'2024-06-06 12:40:51'),
(4,	'Singing',	'2024-06-06 12:40:58',	'2024-06-06 12:40:58');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2024_03_31_084040_create_products_table',	1),
(6,	'2024_04_05_122019_create_countries_table',	1),
(7,	'2024_05_07_060714_create_users_table',	2);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `product_hobbies_mapping`;
CREATE TABLE `product_hobbies_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `hobby_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product_hobbies_mapping` (`id`, `product_id`, `hobby_id`, `created_at`, `updated_at`) VALUES
(10,	2,	4,	'2024-06-26 17:51:54',	'2024-06-26 17:51:54'),
(17,	1,	1,	'2024-06-27 04:38:13',	'2024-06-27 04:38:13');

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('female','male','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` int NOT NULL,
  `state_id` int NOT NULL,
  `city_id` int NOT NULL,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `name`, `email`, `description`, `from_date`, `to_date`, `gender`, `country_id`, `state_id`, `city_id`, `status`, `image`, `created_at`, `updated_at`) VALUES
(1,	'Gulshan',	'gulshanrk654@gmail.com',	'rrr',	'2024-06-03',	'2024-06-10',	'male',	1,	8,	29,	'inactive',	'1719386016.png',	'2024-06-26 01:43:36',	'2024-06-26 23:08:13'),
(2,	'root',	'gulshanrk123@gmail.com',	'fff',	'2024-06-18',	'2024-06-19',	'female',	2,	3,	1,	'active',	'1719386274.png',	'2024-06-26 01:47:55',	'2024-06-26 12:21:54');

DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `country_id` int NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `states` (`id`, `state_name`, `country_id`, `created_at`, `updated_at`) VALUES
(1,	'Alberta',	3,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(2,	'Ontario',	3,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(3,	'California',	2,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(4,	'Arizona',	2,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(5,	'Texas',	2,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(6,	'Andhra Pradesh',	1,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(7,	'Uttar Pradesh',	1,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50'),
(8,	'Maharastra',	1,	'2024-06-10 11:06:50',	'2024-06-10 11:06:50');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1,	'Gulshan',	'gulshanrk654@gmail.com',	'$2y$10$SXmgZkG/lrYZMJ9gzYT2nusQf8ymyeMysSVyyzYU4can8DIbObnmy',	'2024-05-07 01:01:13',	'2024-05-07 01:01:13'),
(3,	'Gulshan',	'gulshanrk4@gmail.com',	'$2y$10$IyG/HzGsBI84cs5Iyo3JkuFVFFuYMquXD2ETN7Eg5oZA6N3eOlkcW',	'2024-05-08 03:20:51',	'2024-05-08 03:20:51');

-- 2024-06-27 05:28:49
