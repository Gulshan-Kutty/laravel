<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create</title>
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="<?php echo e(route('countries.home')); ?>">Homepage</a>
          </li>
        </ul>
    </nav>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
            <div class="card mt-3 p-3">
            <form action="<?php echo e(route('countries.store')); ?>" method='post' enctype='multipart/form-data'>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Country Name</label>
                    <input class='form-control' name='name' type="text" placeholder="Enter country name" value=<?php echo e($info->country_name ?? old('name')); ?>>
                    <?php if($errors->has('name')): ?>
                    <span class='text-danger'><?php echo e($errors->first('name')); ?></span>  
                    <?php endif; ?> 
                </div>
                <div class="form-group">
                    <label for="">Country Code</label>
                    <input class='form-control' name='code' type="text" placeholder="Enter country code" value=<?php echo e($info->country_code ?? old('code')); ?>>
                    <?php if($errors->has('code')): ?>
                    <span class='text-danger'><?php echo e($errors->first('code')); ?></span>  
                    <?php endif; ?> 
                </div>
  
                
                <input type="hidden" name="id" value="<?php echo e($info->id ?? ''); ?>"> 
                <button type="submit" value='<?php echo e($title); ?>' name='button' class='btn btn-primary'><?php echo e($title); ?></button>
                <a class="btn btn-danger" href="<?php echo e(route('countries.home')); ?>">Cancel</a>

            </form>
        </div>
        </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\country_crud\resources\views/countries/create.blade.php ENDPATH**/ ?>