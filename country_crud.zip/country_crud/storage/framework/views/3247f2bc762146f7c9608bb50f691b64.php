<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>homepage</title>
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark">
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="<?php echo e(route('countries.home')); ?>">Homepage</a>
          </li>
        </ul>
      </nav>
      <div class="container">
        <div class="row">
            <h2 class='mt-3 ml-3'>Countries List</h2>
            <button type='submit' class='btn btn-primary mt-3 ml-auto mr-3' onclick="window.location='<?php echo e(route('countries.create')); ?>'">Create Country</button>
        </div>
        
        <table class='table table-bordered mt-2'>
            <tr>
                <th>Sr.No</th>
                <th>Country Name</th>
                <th>Country Code</th>
                <th width="250px">Action</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index +1); ?></td>
                    <td><?php echo e($row->country_name); ?></td>
                    <td><?php echo e($row->country_code); ?></td>
                    <td>
                        <a href="<?php echo e(route('countries.edit', base64_encode($row->id))); ?>" class='btn btn-secondary'>Edit</a>
                        <a href="<?php echo e(route('countries.delete', base64_encode($row->id))); ?>" class="btn btn-danger" onclick="return confirm('Do you really want to remove this record?')">Delete</a>
                        <a href="<?php echo e(route('countries.view', base64_encode($row->id))); ?>" class='btn btn-primary'>View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
        <div class="mt-2">
            <?php echo e($data->links()); ?>

        </div>
    </div>
    </body>
    </html>
<?php /**PATH D:\xampp\htdocs\laravel\country_crud\resources\views/countries/home.blade.php ENDPATH**/ ?>