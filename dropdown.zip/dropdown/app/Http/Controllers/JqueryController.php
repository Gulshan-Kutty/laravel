<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JqueryController extends Controller
{
    //
    public function jquery(){
        return view('home');
}
}
