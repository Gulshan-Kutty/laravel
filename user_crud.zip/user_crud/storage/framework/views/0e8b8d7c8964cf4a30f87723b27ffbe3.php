<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>homepage</title>
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap-toaster.min.css')); ?>">


    <style>
        .navbar {
            height: 80px; /* Change the height value as needed */
        }
    
    </style>
</head>
<body>
    <?php
        // print_r($data1->toArray());exit;
    ?>
    <nav class="navbar navbar-expand-sm bg-dark">
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="<?php echo e(route('users.home')); ?>">Homepage</a>
          </li>
        </ul>
      </nav>
      <div class="container">
        <div class="row">
            <h2 class='mt-3 ml-3'>Products List</h2>
            <button type='submit' class='btn btn-primary mt-3 ml-auto mr-3' onclick="window.location='<?php echo e(route('users.create')); ?>'">Create User</button>
        </div>
        <table class='mt-3' border='2px solid black' cellspacing='0' cellpadding='5px' width='100%'>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Address</th>
                <th>Mobile</th>
                <th>Dob</th>
                <th>Gender</th>
                <th>Country</th>
                <th>State</th>
                <th>City</th>
                <th>Photo</th>
                <th width="250px">Action</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index +1); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->address); ?></td>
                    <td><?php echo e($row->mob); ?></td>
                    <td><?php echo e($row->dob); ?></td>
                    <td><?php echo e($row->gender); ?></td>
                    <td><?php echo e($row->country_name); ?></td>
                    <td><?php echo e($row->state_name); ?></td>
                    <td><?php echo e($row->city_name); ?></td>
                    <td><img src="<?php echo e(url('public/users/'.$row->image)); ?>" class="rounded-circle" width="50" height="50"></td>
                    <td>
                        <a href="<?php echo e(route('users.edit', base64_encode($row->id))); ?>" class='btn btn-info'>Edit</a>
                        <a href="<?php echo e(route('users.delete', base64_encode($row->id))); ?>" class="btn btn-danger" onclick="return confirm('Do you really want to remove this record?')">Delete</a>
                        <a href="<?php echo e(route('users.view', base64_encode($row->id))); ?>" class='btn btn-secondary'>View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
    </div>
    </body>
    </html>
<?php /**PATH D:\xampp\htdocs\laravel\user_crud\resources\views/users/home.blade.php ENDPATH**/ ?>