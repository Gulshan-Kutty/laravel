<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
    <title>Create Page</title>
 
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mt-3 p-3">
                    <form id='form' enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input class="form-control" id="name" name="name" type="text" placeholder="Enter your name" value="<?php echo e($info->name ?? old('name')); ?>">
                            <span class="text-danger" id="nameError"></span>
                            
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea class='form-control' id="address" name="address" placeholder="Enter address" cols="30" rows="10"><?php echo e($info->address ?? old('address')); ?></textarea>
                            <span class="text-danger" id="addressError"></span>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input class="form-control" id="email" name="email" type="text" placeholder="Enter mobile number" value="<?php echo e($info->email ?? old('email')); ?>">
                            <span class="text-danger" id="emailError"></span>
                        </div>
                        <div class="form-group">
                            <label for="mob">Mobile Number</label>
                            <input class="form-control" id="mob" name="mob" type="text" placeholder="Enter mobile number" value="<?php echo e($info->mob_no ?? old('mob')); ?>">
                            <span class="text-danger" id="mobError"></span>
                        </div>
                        <div class="form-group">
                            <label for="dob">DOB</label>
                            <input class="form-control" id="dob" name="dob" type="text" placeholder="Enter your birth date" value="<?php echo e($info->dob ?? old('dob')); ?>">
                            <span class="text-danger" id="dobError"></span>
                        </div>
                        <div class="form-group">
                            <label>Gender</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input gender" type="radio" name="gender" id="male" value="male">
                                <label class="form-check-label" for="male">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input gender" type="radio" name="gender" id="female" value="female">
                                <label class="form-check-label" for="female">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input gender" type="radio" name="gender" id="other" value="other">
                                <label class="form-check-label" for="other">Other</label>
                            </div>
                            <span class="text-danger" id="genderError"></span>
                        </div>
                        <div class="form-group">
                            <label for="country">Select Country</label><br>
                            <select class="dropdown col-sm-6 "  name="country" id='country'>
                                <option value="">Select Country</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row1->id); ?>"><?php echo e($row1->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>   
                        </div> 
                        <div class='form-group'>
                            <label for="state">Select State</label>
                            <select id='state' class="form-control" name="state">
                            </select>
                        </div>
                        <div class='form-group'>
                            <label for="city">Select City</label>
                            <select id='city' class="form-control" name="city">
                            </select>
                        </div>  
                        <div class="form-group">
                            <label for="image">Image</label>
                            <input class='form-control' id="image" name='image' type="file">
                            <span class="text-danger" id="imageError"></span>
                            <?php if(isset($info->image)): ?>
                            <img src="<?php echo e(url('public/users/'.$info->image)); ?>" height='100px' width='100px' alt="Current Image" class='mt-3'>
                            <?php endif; ?> 
                        </div>
                        <input type="hidden" name="id" value="<?php echo e($info->id ?? ''); ?>">
                        <button id='btn' type="submit" value="<?php echo e($title); ?>" name="button" class="btn btn-primary mb-2"><?php echo e($title); ?></button>
                        <a class="btn btn-danger" href="<?php echo e(route('users.home')); ?>">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
    
<script src="<?php echo e(url('public/js/jquery-3.7.1.min.js')); ?>"></script>
<script>
    $('#country').change(function(event){  // used different approach here
                var idCountry = $(this).val();
                // alert(country_id);
                $('#state').html('');

                $.ajax({
                    url : "<?php echo e(route('fetch_state')); ?>",
                    type : 'post',
                    dataType: 'json',
                    data: {
                        country_id: idCountry, _token:"<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response){
                        // console.log(response);
                        // $('#state').html('<option value="">Select State</option>');
                        // $.each(response.states, function(index, state){
                        //     $('#state').append('<option value="'+state.id+'">'+state.name+'</option>');
                        // });
                        $('#state').html(response.html); // Accessing the HTML content from the JSON response

                        $('#city').html('<option value="">Select City</option>');

                    }
                });

            });

            $('#state').change(function(event){ // used different approach here
                var idState = $(this).val();
                // alert(country_id);
                $('#city').html('');

                $.ajax({
                    url : "<?php echo e(route('fetch_city')); ?>",
                    type : 'post',
                    dataType: 'json',
                    data: {
                        state_id: idState, _token:"<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response){ // it takes print_r, echo and json
                        // console.log(response);return false;
                        $('#city').html('<option value="">Select City</option>');
                        $.each(response.cities, function(index, city){
                            $('#city').append('<option value="'+city.id+'">'+city.name+'</option>');
                        });

                    }
                });

            });

            // Ajax without form tag
            // $('#btn').click(function(event) {
            //     // event.preventDefault(); // Prevent the default form submission(i.e after submission it should not refresh the page)

            //     // Prepare form data
            //     var formData = {
            //         name: $('#name').val(),
            //         address: $('#address').val(),
            //         email: $('#email').val(),
            //         mob: $('#mob_no').val(),
            //         dob: $('#dob').val(),
            //         gender: $('#gender').val(),
            //         country_id: $('#country').val(),
            //         state_id: $('#state').val(),
            //         city_id: $('#city').val(),
            //         image: $('#image').val(),
            //         button: $('#btn').val(),
            //         _token:"<?php echo e(csrf_token()); ?>",
            //         // Include other form fields here
            //     };
            //     // event.preventDefault(); // Prevent the default form submission
                
                
            //     // Send an Ajax request to handle form submission
            //     $.ajax({
            //         url: "<?php echo e(route('users.store')); ?>",
            //         type: 'POST',
            //         data: formData,
            //         success: function(response) {
            //             console.log(response);return false;
            //             // Handle success response, for example, show a success message or redirect the user
            //             // alert('message');
            //             window.location.href = "<?php echo e(route('users.home')); ?>"; // Redirect to home page
            //         }
                    
            //     });
            // });


            // Ajax with form tag
            $('#btn').click(function(event){
                event.preventDefault();

                formdata = $('form').serialize();
                console.log(formdata);return false;
                $.ajax({
                    url: "<?php echo e(route('users.store')); ?>",
                    type: 'POST',
                    data: formdata,
                    success: function(response) {
                    // console.log(response);return false;
                    window.location.href = "<?php echo e(route('users.home')); ?>"; // Redirect to home page
                    }
                });
            });
</script>
</html><?php /**PATH D:\xampp\htdocs\laravel\user_crud\resources\views/users/create.blade.php ENDPATH**/ ?>