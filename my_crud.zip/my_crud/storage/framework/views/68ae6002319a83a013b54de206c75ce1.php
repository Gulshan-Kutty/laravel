<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>homepage</title>
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap-toaster.min.css')); ?>">
    
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>  

    <style>
        .navbar {
            height: 80px; /* Change the height value as needed */
        }
    
    </style>
</head>
<body>
    <?php
        // print_r($data1->toArray());exit;
    ?>
    <nav class="navbar navbar-expand-sm bg-dark">
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-light" href="<?php echo e(route('products.home')); ?>">Homepage</a>
          </li>
        </ul>
      </nav>
      <div class="container">
        <div class="row">
            <h2 class='mt-3 ml-3'>Products List</h2>
            <button type='submit' class='btn btn-primary m-3 ml-auto ' onclick="window.location='<?php echo e(route('products.create')); ?>'">Create Product</button>
        </div>
         
        
        <table class='table table-bordered mt-3'>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Description</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Countries</th>
                <th>Image</th>
                <th width="250px">Action</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index +1); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->description); ?></td>
                    <td><?php echo e($row->from_date); ?></td>
                    <td><?php echo e($row->to_date); ?></td>
                    
                    <td><?php echo e($row->country_name); ?></td>
                    <td><img src="<?php echo e(url('public/products/'.$row->image)); ?>" class="rounded-circle" width="50" height="50"></td>
                    <td>
                        <a href="<?php echo e(route('products.edit', base64_encode($row->id))); ?>" class='btn btn-info'>Edit</a>
                        <a href="<?php echo e(route('products.delete', base64_encode($row->id))); ?>" class="btn btn-danger" onclick="return confirm('Do you really want to remove this record?')">Delete</a>
                        <a href="<?php echo e(route('products.view', base64_encode($row->id))); ?>" class='btn btn-secondary'>View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
    </div>
    </body>

    </html>
<?php /**PATH D:\xampp\htdocs\laravel\my_crud\resources\views/products/home.blade.php ENDPATH**/ ?>