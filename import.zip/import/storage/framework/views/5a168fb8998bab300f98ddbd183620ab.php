<!-- import.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSV Import</title>
</head>
<body>
    <h1>CSV Import</h1>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="csv_file">
        <button type="submit">Upload CSV</button>
    </form>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\laravel\import\resources\views/welcome.blade.php ENDPATH**/ ?>